const TheFunixCryptoSim = artifacts.require("TheFunixCryptoSim");

module.exports = function (deployer) {
  deployer.deploy(TheFunixCryptoSim);
};
